# imports básicos
import pickle
import pandas as pd
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from tqdm import tqdm
from copy import deepcopy

# importando bibliotecas para esse modelo
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression

# regressão logística com scaler
class ScaledLR:
    
    # initialization
    def __init__(self, model_params, preproc_params):
        
        # guardando parâmetros
        self.model_params = model_params
        self.preproc_params = preproc_params
        
    # método para ajustar o modelo
    def fit(self, X, y, sample_weight=None):

        # parâmetro requerido para o sklearn
        self.classes_ = np.unique(y)
        
        # se precisarmos do scaler
        if self.preproc_params['use_scaler']:
            self.scaler = StandardScaler()
            X = self.scaler.fit_transform(X)

        # configurando e ajustando a regressão logística
        self.lr = LogisticRegression(**self.model_params)
        self.lr.fit(X,y)
        
    # método para estimar probabilidades
    def predict_proba(self, X):

        # se precisarmos do scaler
        if self.preproc_params['use_scaler']:
            X = self.scaler.transform(X)

        # configurando e ajustando a regressão logística
        y_hat = self.lr.predict_proba(X)        
        
        # retuning probabilities
        return y_hat
    
    # get_params, needed for sklearn estimators
    def get_params(self, deep=True):
        return {'model_params': self.model_params,
                'preproc_params': self.preproc_params}

# importando os modelos
from lightgbm import LGBMClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import OneHotEncoder

# class for the tree-based/logistic regression pipeline
class LGBMLR:
    
    # initialization
    def __init__(self, lgbm_params, lr_params):
        
        # storing parameters
        self.lgbm_params = lgbm_params
        self.lr_params = lr_params 
        
    # method for fitting the model
    def fit(self, X, y, sample_weight=None):
        
        # configuring the models
        self.lr = LogisticRegression(**self.lr_params)
        self.lgbm = LGBMClassifier(**self.lgbm_params)
        self.classes_ = np.unique(y)
        
        # first, we fit our tree-based model on the dataset
        self.lgbm.fit(X, y)
        
        # then, we apply the model to the data in order to get the leave indexes
        leaves = self.lgbm.apply(X)
        
        # then, we one-hot encode the leave indexes so we can use them in the logistic regression
        self.encoder = OneHotEncoder()
        leaves_encoded = self.encoder.fit_transform(leaves)
        
        # and fit it to the encoded leaves
        self.lr.fit(leaves_encoded, y)
        
    # method for predicting probabilities
    def predict_proba(self, X):
        
        # then, we apply the model to the data in order to get the leave indexes
        leaves = self.lgbm.apply(X)
        
        # then, we one-hot encode the leave indexes so we can use them in the logistic regression
        leaves_encoded = self.encoder.transform(leaves)
        
        # and fit it to the encoded leaves
        y_hat = self.lr.predict_proba(leaves_encoded)
        
        # retuning probabilities
        return y_hat
    
    # get_params, needed for sklearn estimators
    def get_params(self, deep=True):
        return {'lgbm_params': self.lgbm_params,
                'lr_params': self.lr_params}

# importando os modelos
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import OneHotEncoder

# class for the tree-based/logistic regression pipeline
class ETLR:
    
    # initialization
    def __init__(self, et_params, lr_params):
        
        # storing parameters
        self.et_params = et_params
        self.lr_params = lr_params 
        
    # method for fitting the model
    def fit(self, X, y, sample_weight=None):
        
        # configuring the models
        self.lr = LogisticRegression(**self.lr_params)
        self.et = ExtraTreesClassifier(**self.et_params)
        self.classes_ = np.unique(y)
        
        # first, we fit our tree-based model on the dataset
        self.et.fit(X, y)
        
        # then, we apply the model to the data in order to get the leave indexes
        leaves = self.et.apply(X)
        
        # then, we one-hot encode the leave indexes so we can use them in the logistic regression
        self.encoder = OneHotEncoder()
        leaves_encoded = self.encoder.fit_transform(leaves)
        
        # and fit it to the encoded leaves
        self.lr.fit(leaves_encoded, y)
        
    # method for predicting probabilities
    def predict_proba(self, X):
        
        # then, we apply the model to the data in order to get the leave indexes
        leaves = self.et.apply(X)
        
        # then, we one-hot encode the leave indexes so we can use them in the logistic regression
        leaves_encoded = self.encoder.transform(leaves)
        
        # and fit it to the encoded leaves
        y_hat = self.lr.predict_proba(leaves_encoded)
        
        # retuning probabilities
        return y_hat
    
    # get_params, needed for sklearn estimators
    def get_params(self, deep=True):
        return {'et_params': self.et_params,
                'lr_params': self.lr_params}


# importando as camadas necessárias
from keras import Model, Sequential
from keras.layers import AveragePooling2D, Dense, Dropout
from keras import optimizers
from sklearn.preprocessing import StandardScaler

# regressão logística com scaler
class ScaledDNN:
    
    # initialization
    def __init__(self, model_params, preproc_params):
        
        # guardando parâmetros
        self.model_params = model_params
        self.preproc_params = preproc_params
        
    # método para ajustar o modelo
    def fit(self, X, y, sample_weight=None):

        # parâmetro requerido para o sklearn
        self.classes_ = np.unique(y)
        
        # se precisarmos do scaler
        if self.preproc_params['use_scaler']:
            self.scaler = StandardScaler()
            X = self.scaler.fit_transform(X)

        # configurando a rede neural
        self.model = Sequential()
        
        # primeira camada densa e dropout
        self.model.add(Dense(units=self.model_params['n_units'], activation='relu', input_dim=X.shape[1]))
        self.model.add(Dropout(self.model_params['drop_rate']))
        
        # número de camadas intermediárias pode variar
        for _ in range(self.model_params['n_layers']):
            self.model.add(Dense(units=self.model_params['n_units'], activation='relu'))
            self.model.add(Dropout(self.model_params['drop_rate']))
        
        # camada final sigmoide normal              
        self.model.add(Dense(units=1, activation='sigmoid'))
        
        # instanciando o otimizador
        sgd = optimizers.SGD(lr=self.model_params['lr'], 
                             decay=self.model_params['decay'], 
                             momentum=self.model_params['momentum'], 
                             nesterov=True)
        
        # compilando o modelo
        self.model.compile(loss='binary_crossentropy', optimizer=sgd)
        
        # ajustando o modelo
        self.model.fit(X, y, verbose=0, epochs=self.model_params['epochs'])
        
    # método para estimar probabilidades
    def predict_proba(self, X):

        # se precisarmos do scaler
        if self.preproc_params['use_scaler']:
            X = self.scaler.transform(X)

        # configurando e ajustando a regressão logística
        y_hat = self.model.predict(X)   
        
        # retuning probabilities
        return np.c_[(1-y_hat), y_hat]
    
    # get_params, needed for sklearn estimators
    def get_params(self, deep=True):
        return {'model_params': self.model_params,
                'preproc_params': self.preproc_params}


# função para organizar os melhores experimentos
def get_best_trials(trials):
    
    # lista para registrarmos os melhores trials
    best_trial_list = []

    # loop para cada um dos trials
    for trial in trials.trials:

        # acumulando as informações necessárias
        temp_info = {'auc': -trial['result']['loss'],
                     'models': trial['result']['models'],
                     'params_process': trial['result']['params_process'],
                     'preds': trial['result']['preds'],
                     'auc_folds': trial['result']['auc']}

        # salvando na lista
        best_trial_list.append(temp_info)

    # transformando em um df
    return pd.DataFrame(best_trial_list).sort_values('auc', ascending=False)

# função para obter previsões de teste
def get_test_predictions(trial, X_test):
    
    # copiando a base para aplicarmos o modelo
    X_test_copy = X_test.copy()
    
    # devemos usar augmentation ou não?
    if not trial['params_process']['use_aug']:
        X_test_copy = X_test_copy.loc[(slice(None),'none'),:]
        
    # lista para acumular previsões de diferentes modelos
    preds_list = []
    
    # loop para cada modelo no trials
    for model in trial['models']:
    
        # gerando previsões
        preds_list.append(model.predict_proba(X_test_copy)[:,1])
    
    # criando série com os IDs das previsões e tipo de augmentation
    preds = pd.Series(np.array(preds_list).mean(axis=0), index=X_test_copy.index, name='preds')
    
    # consolidando as previsões com diversas augmentations no ID
    preds = preds.groupby('id').mean()
    
    # retornando previsões de teste e validação
    return preds, trial['preds']

# importando métrica
from sklearn.metrics import roc_auc_score

# funçõo para obter experimentos em ensemble selection
def get_ensemble_selection(trials_table, y_train):

    # variável alvo a ser comparada
    target = y_train.groupby('id').mean()
    
    # inicializando previsões e contagem de modelos
    preds = 0
    n_models = 1
    selected_models = []
    
    # inicializando acumulador de resultado
    best_auc = 0.0
    
    # loop para cada modelo
    for i, trial in trials_table.iterrows(): 
        
        # novas previsões
        temp_preds = (preds*(n_models-1) + trial['preds'].groupby('id').mean())/n_models
        temp_preds.name = 'preds'
        
        # criando df de avaliação consolidadas por ID (test time auabgmentation)
        eval_df = pd.concat([temp_preds, target], axis=1)
        
        # calculando resultado
        temp_auc = roc_auc_score(eval_df['target'], eval_df['preds'])
        
        # se esse resultado for melhor que o último, atualizar ensemble
        if temp_auc > best_auc:
            preds = temp_preds
            best_auc = temp_auc
            selected_models.append(i)
            n_models += 1
            
    # retornando df com modelos selecionados
    return trials_table.iloc[selected_models], best_auc
