# class for the for the general pipeline
class GeneralPipeline:
    
    # initialization
    def __init__(self, params):
        
        # guardando parâmetros
        self.params = params
        
    # método para ajustar o modelo
    def fit(self, X, y, sample_weight=None):

        # parâmetro requerido para o sklearn
        self.classes_ = np.unique(y)
        
        # código que vai ajustar os modelos 
        
    # método para estimar probabilidades
    def predict_proba(self, X):
        
        # código que vai implementar o predict_proba dos modelos 
        
        # retuning probabilities
        return y_hat
    
    # get_params, needed for sklearn estimators
    def get_params(self, deep=True):
        return {'params': self.params}