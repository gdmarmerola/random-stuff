# imports básicos
import pickle
import pandas as pd
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from tqdm import tqdm
from copy import deepcopy
from sklearn.model_selection import cross_val_predict, StratifiedKFold, KFold, GroupKFold, cross_validate
from sklearn.metrics import roc_auc_score
from hyperopt import fmin, tpe, hp, STATUS_OK, pyll, Trials
import time

# criação da função objetivo do problema
def get_objective_fn(X_in, y_in, pipeline, cv, base_random_state, n_reps=10):
    
    # criando a função a ser retornada
    def objective(params):
        
        # deixando claro para o python que vamos usar X e y
        X, y = X_in, y_in

        # devemos usar augmentation ou não?
        if not params['process']['use_aug']:
            X = X.loc[X.index.get_level_values('augmentation') == 'none']
            y = y.loc[y.index.get_level_values('augmentation') == 'none']

        # separando y sem augmentation
        y_pure = y.loc[(slice(None),'none')]

        # dict para essa validação
        valid_dict = {'preds': [], 'auc': [], 'models': []}

        # para registrarmos o tempo
        start_time = time.time()

        # loop para cada repetição
        for rep_id in range(n_reps):

            # calibrando o random_state
            cv.random_state = base_random_state + rep_id

            # loop de validação, quebrando nos ids únicos
            for train_ids, test_ids in cv.split(y_pure.index, y_pure):

                # configurando o pipeline
                pipe_configured = pipeline(**params['pipeline'])
                        
                # separando as bases
                X_train = X.loc[(y_pure.index[train_ids], slice(None)),:]
                y_train = y.loc[(y_pure.index[train_ids], slice(None))]
                X_test = X.loc[(y_pure.index[test_ids], slice(None)),:]
                y_test = y.loc[(y_pure.index[test_ids], slice(None))]

                # ajustando o modelo
                pipe_configured.fit(X_train, y_train)

                # calculando previsões
                preds = pipe_configured.predict_proba(X_test)

                # criando série com os IDs das previsões e tipo de augmentation
                preds = pd.Series(preds[:,1], index=X_test.index, name='preds')

                # criando df de avaliação consolidadas por ID (test time augmentation)
                eval_df = pd.concat([preds, y_test],axis=1).groupby('id').mean()

                # calculando o score e guardando
                auc = roc_auc_score(eval_df['target'],eval_df['preds'])
                valid_dict['auc'].append(auc)

                # guardando previsões
                valid_dict['preds'].append(preds)

                # guardando modelos
                valid_dict['models'].append(pipe_configured)

        # duração do teste
        delta_time = time.time() - start_time

        # guardando previsões finais de todas as repetições para stacking
        preds_final = pd.concat(valid_dict['preds']).groupby(['id','augmentation']).mean().sort_index()

        # vamos printar os parâmetros
        print(params['pipeline'], params['process'])
        print('AUC:', np.round(np.mean(valid_dict['auc']),6), 'time:', np.round(delta_time))
        print('')

        # retornando modelo configurado e outras informações relevantes
        return {'loss': -np.mean(valid_dict['auc']),
                'status': STATUS_OK,
                'params_process': params['process'],
                'preds': preds_final,
                'models': valid_dict['models'],
                'auc': valid_dict['auc']}

    # retornando função objetivo
    return objective


    # criação da função objetivo do problema
def get_objective_fn2(X_in, y_in, pipeline, cv, base_random_state, n_reps=10):
    
    # criando a função a ser retornada
    def objective(params):
        
        # deixando claro para o python que vamos usar X e y
        X, y = X_in, y_in
        
        # configurando o pipeline
        pipe_configured = pipeline(**params['pipeline'])
        
        # devemos usar augmentation ou não?
        if not params['process']['use_aug']:
            X = X.loc[(slice(None),'none'),:]
            y = y.loc[(slice(None),'none')]
        
        # df para guardar as previsões de todas as repetições
        preds_df = pd.DataFrame()

        # lista para guardar as AUCs de todas as previsões
        auc_list = []
        
        # para registrarmos o tempo
        start_time = time.time()
        
        # loop para cada repetição
        for rep_id in range(n_reps):

            # calibrando o random_state
            cv.random_state = base_random_state + rep_id

            # obtendo previsões
            preds = cross_val_predict(pipe_configured, X, y, cv=cv, 
                                      groups=X.index.get_level_values('id'), 
                                      method='predict_proba')

            # criando série com os IDs das previsões e tipo de augmentation
            preds = pd.Series(preds[:,1], index=X.index, name='preds')

            # criando df de avaliação consolidadas por ID (test time augmentation)
            eval_df = pd.concat([preds.groupby('id').mean(), y.groupby('id').mean()],axis=1)

            # calculando o score e guardando
            auc = roc_auc_score(eval_df['target'], eval_df['preds'])
            auc_list.append(auc)

            # guardando as previsões da repetição no df das previsões
            preds_df = pd.concat([preds_df, preds],axis=1)
        
        # duração do teste
        delta_time = time.time() - start_time
        
        # guardando previsões finais de todas as repetições para stacking
        preds_final = preds_df.mean(axis=1)
        
        # vamos printar os parâmetros
        print(params['pipeline'], params['process'])
        print('AUC:', np.round(np.mean(auc_list),6), 'time:', np.round(delta_time))
        print('')

        # retornando modelo configurado e outras informações relevantes
        return {'loss': -np.mean(auc_list),
                'status': STATUS_OK,
                'params_process': params['process'],
                'preds': preds_final,
                'pipe_configured': pipe_configured}
    
    # retornando função objetivo
    return objective
